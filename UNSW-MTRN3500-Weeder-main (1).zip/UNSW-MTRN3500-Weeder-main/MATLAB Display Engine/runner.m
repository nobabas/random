clear; clc; close all;

runDisplayEngine();