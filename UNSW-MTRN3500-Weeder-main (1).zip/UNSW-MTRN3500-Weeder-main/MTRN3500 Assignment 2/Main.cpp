#include "TMM.h"

int main(void) {

	ThreadManagement^ myTMT = gcnew ThreadManagement();

	myTMT->setupSharedMemory();

	myTMT->threadFunction();

	Console::ReadKey();
	return 0;
}